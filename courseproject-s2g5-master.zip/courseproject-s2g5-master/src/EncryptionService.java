public class EncryptionService {
	
	public String getEncryptionPassword() {
		return ":UX]dmI7b:|{~mD";
	}

}
