public class TeamsService extends Service{
    public TeamsService(DatabaseConnectionService dbService, boolean importing) {
        super(dbService, importing);
    }


}
